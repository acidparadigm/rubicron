# -*- coding: utf-8 -*-
#
# This is a sample robot using some of the plugins in this
# repository, mainly intended for testing purposes. You may
# find it useful as a working usage example of some of the
# plugins.

# Require Cinch
require "cinch"
require "fileutils"

# Require our plugins
require_relative "plugins/echo"
require_relative "plugins/logplus"
require_relative "plugins/link_info"
require_relative "plugins/tickets"
require_relative "plugins/vote"
require_relative "plugins/seen"
require_relative "plugins/quit"
require_relative "plugins/quotes"
require_relative "/home/fractal/.gem/ruby/2.3.0/gems/cinch-nmap-0.2.2/lib/cinch/plugins/cinch-nmap"
require_relative "plugins/channel_record"

FileUtils.mkdir_p("/tmp/logs/plainlogs")
FileUtils.mkdir_p("/tmp/logs/htmllogs")

class Seen < Struct.new(:who, :where, :what, :time)
  def to_s
    "[#{time.asctime}] #{who} was seen in #{where} saying #{what}"
  end
end

$users = {}

# Define the robot
cinch = Cinch::Bot.new do

  configure do |config|

    ########################################
    # Cinch options

    # Server stuff
    config.server     = "irc.supernets.org"
    config.port       = 6697
    config.ssl.use    = true
    config.ssl.verify = false

    # User stuff
    config.channels = ["#superbowl"]
    config.nick     = "rubicron"
    config.user     = "ak"

    ########################################
    # Plugin options

    # Default prefix is the bot’s name
    config.plugins.prefix = lambda{|msg| Regexp.compile("^!:?\s*")}

    config.plugins.options[Cinch::LogPlus] = {
      :plainlogdir => "/tmp/logs/plainlogs",
      :htmllogdir  => "/tmp/logs/htmllogs"
    }

    config.plugins.options[Cinch::Tickets] = {
      :url => "http://example.org/tickets/%d"
    }

    config.plugins.options[Cinch::Seen] = {
      :file => "/tmp/rubicron/seen.dat"
    }

    config.plugins.options[Cinch::Vote] = {
      :auth_required => false,
      :voters => %w[Quintus]
    }

   config.plugins.options[Cinch::LinkInfo] = {
     :blacklist => [/\.xz$/],
     :no_description => false,
   }

    config.plugins.options[Cinch::ChannelRecord] = {
      :file => "/tmp/record.dat"
    }

    config.plugins.options[Cinch::Plugins::Quotes] = {
      :quotes_file => '/tmp/rubicron/quotes.yml'
    }

    config.plugins.plugins = [Cinch::Plugins::ScanNmap]
    #
    ## List of plugins to load
    config.plugins.plugins = [Cinch::Echo, Cinch::Quit, Cinch::ChannelRecord, Cinch::Vote, Cinch::Plugins::Quotes, Cinch::Plugins::ScanNmap]
  end

  on :message, "h" do |m|
    m.reply "h"
  end

  on :message, "hie" do |m|
    m.reply "im so hie"
  end

  on :message, "hi" do |m|
    m.reply "hie"
  end

# Only log channel messages
  on :channel do |m|
    $users[m.user.nick] = Seen.new(m.user.nick, m.channel, m.message, Time.new)
  end

  on :channel, /^!seen (.+)/ do |m, nick|
    if nick == bot.nick
      m.reply "That's me!"
    elsif nick == m.user.nick
      m.reply "That's you!"
    elsif $users.key?(nick)
      m.reply $users[nick].to_s
    else
      m.reply "I haven't seen #{nick}"
    end
end


  trap "SIGINT" do
    bot.log("Cought SIGINT, quitting...", :info)
    bot.quit
  end

  trap "SIGTERM" do
    bot.log("Cought SIGTERM, quitting...", :info)
    bot.quit
  end

  on :message, /foo/ do |msg|
    str = "Testing colors:"
    Cinch::Formatting::Colors.each_key do |color|
      str << " " << Cinch::Formatting.format(color, color.to_s)
    end
    str << " " << Cinch::Formatting.format(:bold, "bold text")
    str << " " << Cinch::Formatting.format(:yellow, Cinch::Formatting.format(:bold, "yellow bold text"))
    str << " " << Cinch::Formatting.format(:underline, "underlined text")
    str << " " << Cinch::Formatting.format(:red, Cinch::Formatting.format(:underline, "red underlined text"))
    str << " " << Cinch::Formatting.format(:green, Cinch::Formatting.format(:bold, Cinch::Formatting.format(:underline, "green bold underlined text")))
    str << " Normal again."
    str << " " << Cinch::Formatting.format(:green, :yellow, "Green on yellow background.")
    str << " " << Cinch::Formatting.format(:green, :yellow, Cinch::Formatting.format(:italic, "Italic green on yellow background."))
    p(str)
    msg.reply(str)
  end

  # Set up a logger so we have something more persistant
  # than $stderr. Note this sadly cannot be done in a
  # plugin, because plugins are loaded after a good number
  # of log messages have already been created.
  file = open("/tmp/cinch.log", "a")
  file.sync = true
  loggers.push(Cinch::Logger::FormattedLogger.new(file))
  loggers.first.level = :debug

end

cinch.start

require "rss"
require "open-uri"

class Cinch::missingchild
    def rssfeed
        url = 'http://www.missingkids.com/missingkids/servlet/XmlServlet?act=rss&LanguageCountry=en_US&orgPrefix=NCMC'
        open(url) do |rss|
	    feed = RSS::Parser.parse(rss)
#		feed.items.each do |item|
		return feed.items.sample.description
    	end
    end

    def missingchatter()
	loop do
	  send "PRIVMSG #{@channel} :#{rssfeed}"
	  m.reply "#{rssfeed}"
	sleep(3600);
    	end
    end
end
